package com.example.spring.ui.spring.ui.demo.controller;

import com.example.spring.ui.spring.ui.demo.model.User;
import com.example.spring.ui.spring.ui.demo.model.UserForm;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
public class HelloWorldController {
    @GetMapping("hello-world")
    public String helloWorld(Model model) {
        model.addAttribute("message", "hello world");
        return "hello-world"; //hello-world.html
    }

    @GetMapping("variable-expression")
    public String variableExpression(Model model) {
        User user = new User("admin", "admin@gmail.com", "admin");
        model.addAttribute("user", user);
        return "variable-expression";
    }

    @GetMapping("selection-expression")
    public String selectionExpression(Model model) {
        User user = new User("admin", "admin@gmail.com", "admin");
        model.addAttribute("user", user);
        return "selection-expression";
    }

    @GetMapping("message-expression")
    public String messageExpression(Model model) {
        return "message-expression";
    }

    @GetMapping("link-expression")
    public String linkExpression(Model model) {
        model.addAttribute("id", 1);
        return "link-expression";
    }

    @GetMapping("fragment-expression")
    public String fragmentExpression() {
        return "fragment-expression";
    }

    @GetMapping("/users")
    public String users(Model model) {
        User admin = new User("admin", "admin@gmail.com", "admin");
        User john = new User("john", "john@gmail.com", "user");
        List<User> users = Arrays.asList(admin, john);
        model.addAttribute("users", users);
        return "users";
    }

    @GetMapping("/if-unless")
    public String ifUnless(Model model) {
        User admin = new User("admin", "admin@gmail.com", "admin");
        User john = new User("john", "john@gmail.com", "user");
        List<User> users = Arrays.asList(admin, john);
        model.addAttribute("users", users);
        return "if-unless";
    }

    @GetMapping("/switch-case")
    public String switchCase(Model model) {
        User admin = new User("admin", "admin@gmail.com", "admin");
        model.addAttribute("user", admin);
        return "switch-case";
    }

    @GetMapping("/register")
    public String userRegistration(Model model) {
        UserForm userForm = new UserForm();
        model.addAttribute("userForm", userForm);


        List<String> professions = Arrays.asList("dev", "qa");
        model.addAttribute("professions", professions);

        return "register";
    }

    @PostMapping("/register/save")
    public String submitForm(Model model, @ModelAttribute("userForm") UserForm userForm) {

       model.addAttribute("userForm",userForm);

        return "register-success";
    }


}
